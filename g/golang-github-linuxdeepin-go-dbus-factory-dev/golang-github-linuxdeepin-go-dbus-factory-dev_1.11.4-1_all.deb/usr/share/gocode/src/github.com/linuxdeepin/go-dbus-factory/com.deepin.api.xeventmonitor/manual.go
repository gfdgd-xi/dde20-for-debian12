// SPDX-FileCopyrightText: 2018 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

package xeventmonitor

type CoordinateRange struct {
	X1, Y1, X2, Y2 int32
}
