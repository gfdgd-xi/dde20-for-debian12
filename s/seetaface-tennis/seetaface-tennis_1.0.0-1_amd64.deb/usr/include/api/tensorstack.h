#ifndef TENNIS_API_TENSORSTACK_H
#define TENNIS_API_TENSORSTACK_H

#pragma message("Using decrepted header, please use #include \"api/tennis.h\" instead")

#include "tennis.h"

#endif //TENNIS_API_TENSORSTACK_H
