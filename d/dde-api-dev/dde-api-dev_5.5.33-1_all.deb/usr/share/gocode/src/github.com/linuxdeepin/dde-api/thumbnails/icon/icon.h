// SPDX-FileCopyrightText: 2018 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef __LOOKUP_H__
#define __LOOKUP_H__

char* choose_icon(char* theme, const char** names, int size);

#endif
