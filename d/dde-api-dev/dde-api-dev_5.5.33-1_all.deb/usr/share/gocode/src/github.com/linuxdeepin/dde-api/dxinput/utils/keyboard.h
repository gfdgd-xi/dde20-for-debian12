// SPDX-FileCopyrightText: 2018 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef __KEYBOARD_H__
#define __KEYBOARD_H__

int set_keyboard_repeat(int repeated, unsigned int delay, unsigned int interval);

#endif
